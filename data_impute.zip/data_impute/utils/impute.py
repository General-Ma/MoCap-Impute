from sklearn.linear_model import LinearRegression

from .metrics import get_res
import numpy as np
import pandas as pd

def impute(s, missing_indexes, data_generation_type, imputation_method, neighbors):
    '''
    data_generation_type=1: single value imputation
    data_generation_type=2: fit using LR
    '''
    s = np.array(s)
    y_true = np.array(s)[missing_indexes]
    y_pred = []
    if data_generation_type==1 or data_generation_type==2: # average: get the average of "neighbors" items
        for i in missing_indexes:
            indexes = [*list(range(i-neighbors,i)),*list(range(i+1,i+neighbors+1))]
            y_pred.append(  s[indexes].sum()/(2*neighbors)  )
        get_res(y_true, y_pred)
   
    elif isinstance(data_generation_type, list):
        if imputation_method=='LR':
            m = LinearRegression()
            data = np.vstack( (list(range(len(s))) ,s ) ).T
            df = pd.DataFrame(data, columns=['ind', 'val'])

            # print('missing_indexes = ', missing_indexes)
            train = df.drop(missing_indexes, axis=0, inplace=False)
            train.to_csv('train.csv')

            # print('np.array(missing_indexes) + 1  = ', np.array(missing_indexes) + 1)
            # print('train["ind"].values.shape ----------', train["ind"].values.reshape(-1,1).shape)
            # print('train["val"].values.reshape(-1,1).shape ----------', train["val"].values.reshape(-1, 1).shape)
            m.fit(train['ind'].values.reshape(-1,1), train['val'].values.reshape(-1,1))
            y_pred = m.predict( np.array(missing_indexes).reshape(-1,1)  )
            # print('missing_indexes = ', missing_indexes)
            test = df.iloc[missing_indexes]
            test['pred'] = y_pred
            test.to_csv('test.csv')
            # print('( np.array(missing_indexes).reshape(-1,1) + 1 ) = ', (np.array(missing_indexes).reshape(-1, 1) + 1))
            get_res(y_true, y_pred)
            # print( 'y_pred = ' , y_pred )
            return data, s
        elif imputation_method=='sliding_avg':
            total_ratio = data_generation_type[0]
            No_of_intervals = data_generation_type[1]
            interval_length = int(total_ratio * len(s) / No_of_intervals)
            print('missing', missing_indexes)
            for i in range(No_of_intervals):
                tmp_missing_indexes = missing_indexes[i*interval_length:(i+1)*interval_length]
                print('\n\n%d:'%i, tmp_missing_indexes)
                print('end_points ', tmp_missing_indexes[-1]+1, tmp_missing_indexes[-1] + neighbors )
                print('prev_points ', tmp_missing_indexes[0]-neighbors, tmp_missing_indexes[0]-1)
                end_points = s[ tmp_missing_indexes[-1]+1: tmp_missing_indexes[-1] + neighbors+1]
                prev_points = list(s[ tmp_missing_indexes[0]-neighbors: tmp_missing_indexes[0]-1+1])
                print('_-_-_-_-_-> 1\n')
                for j in tmp_missing_indexes:
                    print('\n==prev_points = ', prev_points)
                    print('==end_points = ', end_points)
                    print('===',prev_points[-2:], sum(prev_points[-2:]),end_points, sum(end_points) )
                    pred_value = (sum(end_points) + sum(prev_points[-2:])) / (2*neighbors)
                    prev_points.append( pred_value )
                    y_pred.append( pred_value  )

            get_res(y_true, y_pred)
            dd = pd.DataFrame()
            dd['series'] = s
            dd['y_true'] = ''
            dd['y_pred'] = ''
            dd.loc[missing_indexes, 'y_true'] = y_true
            dd.loc[missing_indexes, 'y_pred'] = y_pred
            dd.to_csv('tmp.csv')
            return y_true, y_pred





