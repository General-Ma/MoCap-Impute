import random
import matplotlib.pyplot as plt

def generate_problem_data( df, angle_index, missing_count, data_generation_type=1, plt_=True ):
    '''
    data_generation_type ==1 : random points
    data_generation_type ==2 : transition points
    data_generation_type ==[total_ratio, No_of_intervals]:  number of "total_ratio" distributed between "No_of_intervals" intervals.
    '''
    s = df.pop(str(angle_index))
    missing_index = []
    
    transition_p = None
    if isinstance(data_generation_type, int):    
        if data_generation_type ==1:
            #print('data_generation_type_1')
            missing_index = random.sample(range(len(s)), missing_count)

        elif data_generation_type==2:
            #print('data_generation_type_2')
            tmp = []

            # get transition indexes
            for i in range(1,len(s)-1):
                if s[i]<s[i-1] and s[i]<s[i+1]:
                    tmp.append(i)
                elif s[i]>s[i-1] and s[i]>s[i+1]:
                    tmp.append(i)

            transition_p = len(tmp)
            #print( 'No of Transition points:' , transition_p )
            random.shuffle(tmp)

            if missing_count <= len(tmp):
                for c in range(missing_count):
                    missing_index.append(tmp[c])
            else:
                for c in range(len(tmp)):
                    missing_index.append(tmp[c])
                while len(missing_index) != missing_count:
                    n = random.sample(range(len(s)), 1)
                    if n[0] not in missing_index:
                        missing_index.append(n[0])

        if plt_ is not None:
            plt.rcParams["figure.figsize"] = [15,7]
            plt.plot(s)
            for j in range(len(missing_index)):
                i = missing_index[j]
                if transition_p is not None and j < transition_p:
                    plt.scatter(i, s[i], s=plt_, c='r', alpha=0.5)
                else:
                    plt.scatter(i, s[i], s=plt_, c='#17becf', alpha=0.9)
    
    elif isinstance(data_generation_type, list):
        total_ratio = data_generation_type[0]
        No_of_intervals = data_generation_type[1]
        interval_length = int(total_ratio*len(s)/No_of_intervals)
        
        flag = True
        pos = [0] # len(s)/No_of_intervals
        flag = True
        for i in range(1, No_of_intervals+1):
            pos.append( int(len(s)/No_of_intervals) * i )
            if flag and (total_ratio*len(s)%No_of_intervals) !=0:
                flag = False
                interval_length = interval_length+1
            elif not flag:
                interval_length = interval_length - 1
            starting = random.randint(pos[i-1],pos[i]-interval_length)
            #print( 'interval_%d starting = '%i , starting, interval_length )
            missing_index.extend(list(range(starting, starting+interval_length)))

            

    
        if plt_ is not None:
            plt.rcParams["figure.figsize"] = [15,7]
            plt.plot(s)
            for i in missing_index:
                plt.scatter(i, s[i], s=30, c='r', alpha=0.5)
                
    return s, missing_index