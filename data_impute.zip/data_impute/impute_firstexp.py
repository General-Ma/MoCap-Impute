import os
import pandas as pd
import numpy as np
import tensorflow.compat.v1 as tf

tf.disable_v2_behavior()
from tqdm import tqdm
from models.OTimputer import *
from models.gain import *
from utils.data import *
from utils.gain_utils import *
from utils.ot_utils import *
from fancyimpute import *
from utils.shaerd_memory import *
from multiprocessing import Process
import math
import argparse
import json
import random


def get_data(csv_path, data_generation_type=2, missing_count=10):
    df = pd.read_csv(csv_path)
    df.drop(columns=['Unnamed: 0'], inplace=True)
    df.columns = [str(i) for i in range(df.shape[1])]
    missing_df = df.copy()
    for i in range(39):
        _, missing_index = generate_problem_data(df.copy(),
                                                 angle_index=i,  # which (series) to work on
                                                 missing_count=missing_count,
                                                 data_generation_type=data_generation_type,
                                                 plt_=None)
        assert len(
            missing_index) == missing_count, f'expected missing indices = {missing_count}, got {len(missing_index)}____{data_generation_type}'
        missing_df.loc[missing_index, str(i)] = np.nan
    missing_array = np.array(missing_df)
    return np.array(df), missing_array, np.isnan(missing_array)


def get_skill_data(skill_path, data_generation_type, n_players, n_angles, n_rows, missing_count):
    csv_files = sorted([f for f in os.listdir(skill_path) if f.endswith('.csv')])
    if len(csv_files) == 0:
        raise ValueError(f'No CSV files found in {skill_path}')

    if len(csv_files) != n_players:
        print(f'Warning: n_players ({n_players}) does not match number of CSV files ({len(csv_files)}) in {skill_path}.')
        n_players = len(csv_files)

    n_types = len(data_generation_type)
    sample_full, _, _ = get_data(f'{skill_path}/{csv_files[0]}', data_generation_type=data_generation_type[0],
                                 missing_count=missing_count)
    n_rows, n_angles = sample_full.shape

    full_skill_data = np.zeros((n_types, n_players, n_rows, n_angles))
    missing_skill_data = np.zeros((n_types, n_players, n_rows, n_angles))
    mask_skill_data = np.zeros((n_types, n_players, n_rows, n_angles))

    for i, type in enumerate(data_generation_type):
        for idx, csvFile in enumerate(csv_files):
            full_data, missing_array, mask = get_data(f'{skill_path}/{csvFile}', data_generation_type=type,
                                                      missing_count=missing_count)
            if full_data.any() > 400:
                print(csvFile)
            full_skill_data[i, idx, :, :] = full_data
            missing_skill_data[i, idx, :, :] = missing_array
            mask_skill_data[i, idx, :, :] = mask

    return full_skill_data, missing_skill_data, mask_skill_data

    """
    
    GAN
    Authors: {Jinsung Yoon, James Jordon, Mihaela van der Schaar}
    Paper Link: [Missing Data Imputation using Generative Adversarial Nets](http://proceedings.mlr.press/v80/yoon18a/yoon18a.pdf)


    OT Imputer 
    Authors: {Muzellec, Boris and Josse, Julie and Boyer, Claire and Cuturi, Marco}
    Paper Link: [Missing Data Imputation using Optimal Transport](https://arxiv.org/abs/2002.03860)
        
    
    fancyimpute: An Imputation Library
    author = {Alex Rubinsteyn and Sergey Feldman},
    url = {https://github.com/iskandr/fancyimpute},
    
    """


def init_models():
    gain = Gain()  # Missing Data Imputation using Generative Adversarial Nets
    bsi = BatchSinkhornImputation()  # first algorithm in Missing Data Imputation using Optimal Transport
    simplefill_mean = SimpleFill('mean')
    simplefill_median = SimpleFill('median')
    simplefill_random = SimpleFill('random')
    knn = KNN(verbose=False)
    soft_imputer = SoftImpute(verbose=False)
    iterative_imputer = IterativeImputer(verbose=False)
    iterative_SVD = IterativeSVD(verbose=False)

    models = [
        gain, bsi,
        simplefill_mean,
        simplefill_median, simplefill_random,
        knn, soft_imputer,
        iterative_imputer,
        iterative_SVD
    ]

    return models


# missing shape(100,)
# shared imputed shape (models,type,players,rows,angles)
def run_single(missing, shared_imputed, idx):
    models = init_models()
    for i, model in enumerate(models):
        try:
            if (np.isnan(missing).sum() == 0):
                print(f'Nan not found single{idx} .... the process will terminate')
                imputed = missing
            else:
                imputed = model.fit_transform(missing.reshape(-1, 1)).reshape(-1, )
            if isinstance(imputed, np.ndarray):
                shared_imputed[i, idx[0], idx[1], :, idx[2]] = imputed
            else:
                shared_imputed[i, idx[0], idx[1], :, idx[2]] = imputed.detach().numpy()

        except:
            shared_imputed[i, idx[0], idx[1], :, idx[2]] = (np.ones_like(missing.reshape(-1, 1)) * np.nan).reshape(-1, )


# missing shape(100,53)
def run_multi_players(missing, shared_imputed, idx):
    models = init_models()
    for i, model in enumerate(models):
        try:
            if (np.isnan(missing).sum() == 0):
                print(f'Nan not found players{idx} .... the process will terminate')
                imputed = missing
            else:
                imputed = model.fit_transform(missing)
            if isinstance(imputed, np.ndarray):
                shared_imputed[i, idx[0], :, :, idx[1]] = imputed.T
            else:
                shared_imputed[i, idx[0], :, :, idx[1]] = imputed.detach().numpy().T

        except:
            shared_imputed[i, idx[0], :, :, idx[1]] = (np.ones_like(missing) * np.nan).T


# missing shape(100,39)
def run_multi_angles(missing, shared_imputed, idx):
    models = init_models()
    for i, model in enumerate(models):
        try:
            if (np.isnan(missing).sum() == 0):
                print(f'Nan not found angles{idx} .... the process will terminate')
                imputed = missing
            else:
                imputed = model.fit_transform(missing)
            if isinstance(imputed, np.ndarray):
                shared_imputed[i, idx[0], idx[1], :, :] = imputed
            else:
                shared_imputed[i, idx[0], idx[1], :, :] = imputed.detach().numpy()

        except:

            shared_imputed[i, idx[0], idx[1], :, :] = (np.ones_like(missing) * np.nan)


def init_processes_single(missing_skill_data, shared_imputed):
    _type, players, _, angles = missing_skill_data.shape
    processes = []
    for i in range(_type):
        for j in range(players):
            for k in range(angles):
                processes.append(
                    Process(target=run_single, args=[missing_skill_data[i, j, :, k], shared_imputed, (i, j, k)]))
    return processes


def init_processes_multi_players(missing_skill_data, shared_imputed):
    _type, _, _, angles = missing_skill_data.shape
    processes = []
    for i in range(_type):
        for k in range(angles):
            processes.append(
                Process(target=run_multi_players, args=[missing_skill_data[i, :, :, k].T, shared_imputed, (i, k)]))
    return processes


def init_processes_multi_angles(missing_skill_data, shared_imputed):
    _type, players, _, _ = missing_skill_data.shape
    processes = []
    for i in range(_type):
        for j in range(players):
            processes.append(
                Process(target=run_multi_angles, args=[missing_skill_data[i, j, :, :], shared_imputed, (i, j)]))
    return processes


def run_team_of_threads(start, end, processes):
    for j in range(start, end):
        processes[j].start()
    for j in range(start, end):
        processes[j].join()
        processes[j].close()

    print(f'The team has finished its tasks successfully {start} - {end}')


def main(missing_count, nan_generation_type, skill_path, impute_type, n_players, n_angles, n_rows, n_threads):
    random.seed(1)

    full_skill_data, missing_skill_data, mask_skill_data = get_skill_data(f'data/{skill_path}', nan_generation_type,
                                                                          n_players, n_angles, n_rows, missing_count)
    n_types = len(nan_generation_type)

    imputed = np.zeros((3, n_types, n_players, n_rows, n_angles))
    make_shared_array(imputed, name='shared_imputed')
    shared_imputed = get_shared_array('shared_imputed', (3, n_types, n_players, n_rows, n_angles))

    processes = []

    if impute_type == 1:
        processes = init_processes_single(missing_skill_data, shared_imputed)
        str_impute_type = 'single'
    elif impute_type == 2:
        processes = init_processes_multi_players(missing_skill_data, shared_imputed)
        str_impute_type = 'multi_players'
    elif impute_type == 3:
        processes = init_processes_multi_angles(missing_skill_data, shared_imputed)
        str_impute_type = 'multi_angles'
    print(len(processes))
    n_it = math.ceil(len(processes) / n_threads)
    start = 0
    for _ in tqdm(range(n_it)):
        end = min(start + n_threads, len(processes))
        run_team_of_threads(start, end, processes)
        start = end
    # ensure output directory exists
    out_dir = f'output/{missing_count}/{str_impute_type}/{skill_path}'
    os.makedirs(out_dir, exist_ok=True)

    with open(f'{out_dir}/imputed.npy', 'wb') as f:
        np.save(f, shared_imputed)
    with open(f'{out_dir}/original.npy', 'wb') as f:
        np.save(f, full_skill_data)
    with open(f'{out_dir}/missing.npy', 'wb') as f:
        np.save(f, missing_skill_data)
    with open(f'{out_dir}/mask.npy', 'wb') as f:
        np.save(f, mask_skill_data)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("--missing", type=int, help="missing count")
    parser.add_argument("--type", metavar='json', type=str, help="data generation type")
    parser.add_argument("--path", type=str, help="skill path")
    parser.add_argument('--impute_type', type=int,
                        help='wether impute with single var imputer or multivar imputer \n 1.single var\n2.multivar over all players\n3.multivar over all angles')
    parser.add_argument('--n_players', type=int, help='number of players')
    parser.add_argument('--n_angles', type=int, help='number of angles')
    parser.add_argument('--n_rows', type=int, help='number of rows')
    parser.add_argument('--n_threads', type=int, help='number of threads in your machine')
    args = parser.parse_args()
    _type = json.loads(args.type)
    main(int(args.missing), _type, args.path, int(args.impute_type), int(args.n_players), int(args.n_angles),
         int(args.n_rows), int(args.n_threads))
