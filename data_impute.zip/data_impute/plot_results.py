import numpy as np
import matplotlib.pyplot as plt
import os
import argparse
from sklearn.metrics import mean_absolute_error


def load_data(missing_count, impute_type):
    with open(f'output/{missing_count}/{impute_type}/skill_1/imputed.npy', 'rb') as f:
        imputed = np.load(f)

    with open(f'output/{missing_count}/{impute_type}/skill_1/original.npy', 'rb') as f:
        original = np.load(f)

    with open(f'output/{missing_count}/{impute_type}/skill_1/mask.npy', 'rb') as f:
        mask = np.load(f)
    return imputed, original, mask


def plot(missing_type, player_number, angle_number, model_idx, missing_count, impute_type):
    plt.rcParams["figure.figsize"] = [15, 7]
    plt.plot(original[missing_type, player_number, :, angle_number], label='Original series')
    p1_flag = True
    p2_flag = True
    p1_label = 'Imputed value'
    p2_label = f'{missing_types[missing_type]} point missing value'
    for i in range(100):
        if mask[missing_type, player_number, i, angle_number] == True:
            plt.scatter(i, imputed[model_idx, missing_type, player_number, i, angle_number],
                        marker='x', c='r', label=p1_label, s=100)
            plt.scatter(i, original[missing_type, player_number, i, angle_number], c='black', label=p2_label,
                        alpha=0.7)
            if p1_flag:
                p1_flag = False
                p1_label = None
            if p2_flag:
                p2_flag = False
                p2_label = None
    label_size = 30
    plt.xlabel("Series points", fontsize=label_size)  # label on x-axis
    plt.ylabel("Values", fontsize=label_size)
    plt.rcParams['xtick.labelsize'] = 20  # size of points on x-axis
    plt.rcParams['ytick.labelsize'] = 20
    plt.xticks(rotation=30)
    plt.legend(fontsize=17)
    mae = mean_absolute_error(
        original[missing_type, player_number,
        mask[missing_type, player_number, :, angle_number].astype(bool),
        angle_number],
        imputed[
            model_idx, missing_type, player_number,
            mask[missing_type, player_number, :, angle_number].astype(bool), angle_number])
    plt.savefig(
        f'figures/{missing_count}/{impute_type}/{missing_types[missing_type]}_{models[model_idx]}_mae_{mae}_player_{player_number}_angle_{angle_number}.pdf',
        bbox_inches='tight')
    plt.cla()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("--missing_count", type=int, help="missing count")
    parser.add_argument("--missing_type", type=int, help="missing type, 0. Random 1. Transition 2. Interval")
    parser.add_argument('--impute_type', type=str,
                        help='single, multi_players, multi_angles')
    parser.add_argument('--player_number', type=int, help='player number')
    parser.add_argument('--angle_number', type=int, help='angle number')
    parser.add_argument('--model_idx', type=int, help="""model idx ["gain", "bsi",
        "simplefill_mean",
        "simplefill_median", "simplefill_random",
        "knn", "soft_imputer",
        "iterative_imputer",
        "iterative_SVD"] """)
    args = parser.parse_args()
    os.makedirs(f'figures/{args.missing_count}/{args.impute_type}', exist_ok=True)
    missing_types = ['Random', 'Transition', 'Interval']
    models = [
        "gain", "bsi",
        "simplefill_mean",
        "simplefill_median", "simplefill_random",
        "knn", "soft_imputer",
        "iterative_imputer",
        "iterative_SVD"
    ]
    imputed, original, mask = load_data(args.missing_count, args.impute_type)
    plot(args.missing_type, args.player_number, args.angle_number, args.model_idx, args.missing_count, args.impute_type)
