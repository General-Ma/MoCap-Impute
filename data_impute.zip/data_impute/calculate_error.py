import os

import numpy as np


def load_data(missing_count, impute_type):
    with open(f'output/{missing_count}/{impute_type}/skill_1/imputed.npy', 'rb') as f:
        imputed = np.load(f)

    with open(f'output/{missing_count}/{impute_type}/skill_1/original.npy', 'rb') as f:
        original = np.load(f)

    with open(f'output/{missing_count}/{impute_type}/skill_1/mask.npy', 'rb') as f:
        mask = np.load(f)
    return imputed, original, mask


def calculate_error_multiplayer(imputed, original, mask):
    n_players = imputed.shape[0]
    n_angles = imputed.shape[2]
    results_mae = np.zeros((n_players, n_angles))
    results_std = np.zeros((n_players, n_angles))
    for j in range(n_angles):
        single_mask = mask[:, :, j]

        single_imputed = imputed[single_mask, j]
        single_original = original[single_mask, j]
        if single_mask.sum() > 0:
            mae = np.sum(np.abs(single_original -
                                single_imputed)) / single_mask.sum()
            std = np.std(np.abs(single_original - single_imputed), ddof=1)
            results_mae[:, j] = mae
            results_std[:, j] = std
    return results_mae, results_std


def calculate_error_multiangle(imputed, original, mask):
    n_players = imputed.shape[0]
    n_angles = imputed.shape[2]
    results_mae = np.zeros((n_players, n_angles))
    results_std = np.zeros((n_players, n_angles))
    for i in range(n_players):
        single_mask = mask[i, :, :]

        single_imputed = imputed[i, single_mask]
        single_original = original[i, single_mask]
        if single_mask.sum() > 0:
            mae = np.sum(np.abs(single_original -
                                single_imputed)) / single_mask.sum()
            std = np.std(np.abs(single_original - single_imputed), ddof=1)
            results_mae[i, :] = mae
            results_std[i, :] = std
    return results_mae, results_std


def calculate_error_single(imputed, original, mask):
    n_players = imputed.shape[0]
    n_angles = imputed.shape[2]
    results_mae = np.zeros((n_players, n_angles))
    results_std = np.zeros((n_players, n_angles))
    for i in range(n_players):
        for j in range(n_angles):
            single_mask = mask[i, :, j]

            single_imputed = imputed[i, single_mask, j]
            single_original = original[i, single_mask, j]
            if single_mask.sum() > 0:
                mae = np.sum(np.abs(single_original -
                                    single_imputed)) / single_mask.sum()
                std = np.std(np.abs(single_original - single_imputed), ddof=1)
                results_mae[i, j] = mae
                results_std[i, j] = std
    return results_mae, results_std


def main(impute_type):
    missing_counts = [5, 10, 15, 20, 25, 30]
    models = ["gain", "bsi", "simplefill_mean", "simplefill_median", "simplefill_random",
              "knn", "soft_imputer", "iterative_imputer", "iterative_SVD"]
    MAE = np.zeros((len(models), 3, 53, 100, 39))
    STD = np.zeros((len(models), 3, 53, 100, 39))

    for missing_count in enumerate(missing_counts):
        os.makedirs(f"results/{missing_count}/skill_1", exist_ok=True)
        for missing_type_idx in [0, 1, 2]:
            imputed, original, mask = load_data(missing_count, impute_type)
            for model_idx, model in enumerate(models):
                if impute_type == "single":
                    mae, std = calculate_error_single(imputed[model_idx, missing_type_idx]
                                                      , original[missing_type_idx], mask[missing_type_idx])
                elif impute_type == "multi_players":
                    mae, std = calculate_error_multiplayer(imputed[model_idx, missing_type_idx]
                                                           , original[missing_type_idx], mask[missing_type_idx])
                elif impute_type == "multi_angles":
                    mae, std = calculate_error_multiangle(imputed[model_idx, missing_type_idx]
                                                          , original[missing_type_idx], mask[missing_type_idx])

                MAE[model_idx, missing_type_idx] = mae
                STD[model_idx, missing_type_idx] = std

                with open(f'results/{missing_count}/{impute_type}/skill_1/MAE.npy', 'wb') as f:
                    np.save(f, MAE)
                with open(f'results/{missing_count}/{impute_type}/skill_1/STD.npy', 'wb') as f:
                    np.save(f, STD)


if __name__ == "__main__":
    main("single")
    main("multi_players")
    main("multi_angles")
