#!/bin/bash
python3 impute_firstexp.py --missing 10 --type [1,2,[0.1,2]] --path skill_1 --impute_type 1 --n_players 2 --n_angles 39 --n_rows 100 --n_threads 24 ;
python3 impute_firstexp.py --missing 10 --type [1,2,[0.1,2]] --path skill_1 --impute_type 2 --n_players 2 --n_angles 39 --n_rows 100 --n_threads 24 ;
python3 impute_firstexp.py --missing 10 --type [1,2,[0.1,2]] --path skill_1 --impute_type 3 --n_players 2 --n_angles 39 --n_rows 100 --n_threads 24 ;
echo '10%'
